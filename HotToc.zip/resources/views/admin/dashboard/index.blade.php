@extends('admin.layout.index')

@section('content')
<div id="page-wrapper">
	<h1>Chào mừng đến với trang chủ Admin</h1>
</div>
@endsection